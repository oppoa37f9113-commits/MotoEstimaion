MotoEstimaion Android App — โปรเจกต์สำหรับสร้าง APK

สิ่งที่มีในโปรเจกต์
- แอป Android ชื่อ MotoEstimaion
- เปิดเครื่องคำนวณจากไฟล์ภายในแอป (ใช้งานออฟไลน์ ไม่ต้องเปิด Chrome)
- ใช้ WebView พร้อมเปิด JavaScript และ DOM Storage เพื่อให้ปุ่มและการบันทึกทำงาน
- รองรับ Android 6.0 ขึ้นไป (minSdk 23)

วิธีสร้าง APK ด้วย Android Studio
1. ติดตั้ง Android Studio บนคอมพิวเตอร์
2. แตกไฟล์ ZIP นี้
3. Android Studio > Open > เลือกโฟลเดอร์ MotoEstimaion_Android
4. รอ Gradle Sync และติดตั้ง Android SDK Platform 35 หากระบบร้องขอ
5. เลือก Build > Build Bundle(s) / APK(s) > Build APK(s)
6. ไฟล์ APK จะอยู่ที่ app/build/outputs/apk/debug/app-debug.apk

หมายเหตุ
- ไฟล์ที่ส่งนี้เป็นซอร์สโปรเจกต์ Android พร้อมสร้าง APK ไม่ใช่ไฟล์ APK ที่คอมไพล์แล้ว
- สภาพแวดล้อมที่ใช้สร้างไฟล์นี้ไม่มี Android SDK/Gradle จึงไม่สามารถคอมไพล์และทดสอบ APK จริงในที่นี้ได้
- ฐานข้อมูลรุ่นรถในเครื่องคำนวณเป็นข้อมูลอ้างอิงเบื้องต้น โปรดตรวจสอบตามปี/รุ่นย่อยกับคู่มือผู้ผลิต
